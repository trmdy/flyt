// flyt — Vault settings + migration flow.

const VAULT_PRESETS = ["~/Documents/flyt", "~/Notes", "~/iCloud/flyt", "~/Dropbox/vault"];

const SettingsModal = ({ vaultPath, docs, onClose, onMigrate }) => {
  const [path, setPath] = React.useState(vaultPath);
  const [step, setStep] = React.useState("edit"); // edit | confirm | migrating | done
  const [progress, setProgress] = React.useState(0);
  const changed = path.trim() && path.trim() !== vaultPath;
  const total = docs.length;

  React.useEffect(() => {
    if (step !== "migrating") return;
    let i = 0;
    const tick = setInterval(() => {
      i += 1;
      setProgress(i);
      if (i >= total) {
        clearInterval(tick);
        setTimeout(() => setStep("done"), 260);
      }
    }, Math.max(120, Math.min(360, 1400 / Math.max(1, total))));
    return () => clearInterval(tick);
  }, [step, total]);

  React.useEffect(() => {
    if (step === "done") {
      const t = setTimeout(() => { onMigrate(path.trim()); }, 700);
      return () => clearTimeout(t);
    }
  }, [step]);

  const movingDoc = docs[Math.min(progress, total - 1)];

  return (
    <div className="scrim" onMouseDown={(e) => { if (e.target === e.currentTarget && step === "edit") onClose(); }}>
      <div className="sheet">
        <div className="sheet-head">
          <div className="sheet-title"><Icon name="folder" size={15}/><span>Vault</span></div>
          {step === "edit" && <button className="iconbtn" onClick={onClose} aria-label="Close"><Icon name="x" size={15}/></button>}
        </div>

        {step === "edit" && (
          <div className="sheet-body">
            <p className="sheet-desc">
              Every flyt document lives in one folder on disk. Pointing flyt at a new
              location moves the entire vault — all {total} documents go with it.
            </p>
            <label className="field-label">Vault location</label>
            <div className="path-field">
              <Icon name="folder" size={14}/>
              <input value={path} onChange={(e) => setPath(e.target.value)} spellCheck={false} placeholder="~/path/to/vault"/>
            </div>
            <div className="preset-row">
              {VAULT_PRESETS.map((p) => (
                <button key={p} className={"preset" + (p === path ? " on" : "")} onClick={() => setPath(p)}>{p}</button>
              ))}
            </div>
            <div className="sheet-actions">
              <button className="btn-ghost" onClick={onClose}>Cancel</button>
              <button className="btn-ink" disabled={!changed} onClick={() => setStep("confirm")}>
                {changed ? "Move vault…" : "No changes"}
              </button>
            </div>
          </div>
        )}

        {step === "confirm" && (
          <div className="sheet-body">
            <div className="migrate-paths">
              <div className="mp-row"><span className="mp-label">From</span><span className="mp-path old">{vaultPath}</span></div>
              <div className="mp-arrow"><Icon name="arrow-down" size={15}/></div>
              <div className="mp-row"><span className="mp-label">To</span><span className="mp-path new">{path.trim()}</span></div>
            </div>
            <p className="sheet-desc">
              <b>{total} documents</b> will be moved and their paths rewritten. Nothing is lost — this just relocates the vault.
            </p>
            <div className="sheet-actions">
              <button className="btn-ghost" onClick={() => setStep("edit")}>Back</button>
              <button className="btn-ink" onClick={() => { setProgress(0); setStep("migrating"); }}><Icon name="arrow-right" size={14}/><span>Migrate {total} files</span></button>
            </div>
          </div>
        )}

        {step === "migrating" && (
          <div className="sheet-body">
            <div className="migrate-status">
              <div className="spinner"/>
              <div>
                <div className="migrate-now">Moving <span className="path-mono">{movingDoc ? movingDoc.filename + ".md" : ""}</span></div>
                <div className="migrate-count">{progress} of {total}</div>
              </div>
            </div>
            <div className="bar"><div className="bar-fill" style={{ width: (total ? (progress / total) * 100 : 100) + "%" }}/></div>
            <div className="migrate-to">→ {path.trim()}</div>
          </div>
        )}

        {step === "done" && (
          <div className="sheet-body">
            <div className="migrate-done">
              <div className="done-check"><Icon name="check" size={22} stroke={2.2}/></div>
              <div className="migrate-now">Vault moved</div>
              <div className="migrate-count">{total} documents now live in <span className="path-mono">{path.trim()}</span></div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

window.SettingsModal = SettingsModal;
