// flyt — Home / library view

const HomeView = ({ docs, vaultPath, query, setQuery, onOpen, onNew, onOpenSettings, density }) => {
  const [activeTag, setActiveTag] = React.useState(null);
  const searchRef = React.useRef(null);
  const tags = FlytStore.allTags(docs);

  const q = query.trim().toLowerCase();
  const filtered = docs
    .filter((d) => !activeTag || (d.tags || []).includes(activeTag))
    .filter((d) => {
      if (!q) return true;
      const hay = (d.title + " " + (d.tags || []).join(" ") + " " + FlytStore.previewText(d.html)).toLowerCase();
      return hay.includes(q);
    })
    .sort((a, b) => b.updated - a.updated);

  const compact = density === "compact";

  return (
    <div className="flyt">
      <div className="appbar">
        <div className="brand">
          <span className="brand-mark"><FlytMark size={17}/></span>
          <span className="brand-name">flyt</span>
        </div>
        <div style={{ flex: 1 }}/>
        <div className="home-search">
          <Icon name="search" size={14}/>
          <input
            ref={searchRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search documents…"
          />
          {query
            ? <button className="home-search-clear" onClick={() => setQuery("")} aria-label="Clear"><Icon name="x" size={12}/></button>
            : <Kbd>⌘K</Kbd>}
        </div>
        <button className="btn-ink" onClick={onNew}>
          <Icon name="plus" size={14}/>
          <span>Create</span>
        </button>
        <button className="iconbtn" onClick={onOpenSettings} title="Vault settings" aria-label="Vault settings">
          <Icon name="settings" size={16}/>
        </button>
      </div>

      <div className="home-scroll">
        <div className="home-inner">
          <div className="entries-head">
            <div className="entries-title">{activeTag ? "#" + activeTag : "All documents"}</div>
            <div className="entries-sub">{filtered.length} {filtered.length === 1 ? "document" : "documents"}</div>
          </div>

          {tags.length > 0 && (
            <div className="chips">
              <button className={"chip" + (activeTag === null ? " active" : "")} onClick={() => setActiveTag(null)}>
                <span>All</span><span className="count">{docs.length}</span>
              </button>
              {tags.map((t) => (
                <button key={t.tag} className={"chip" + (activeTag === t.tag ? " active" : "")} onClick={() => setActiveTag(activeTag === t.tag ? null : t.tag)}>
                  <span>{t.tag}</span><span className="count">{t.count}</span>
                </button>
              ))}
            </div>
          )}

          <div className="entry-list">
            {filtered.map((d) => (
              <div className={"entry" + (compact ? " entry-compact" : "")} key={d.id} onClick={() => onOpen(d.id)}>
                <div className="entry-main">
                  <div className="entry-title">{d.title || "Untitled"}</div>
                  {!compact && <div className="entry-preview">{FlytStore.previewText(d.html) || "Empty document"}</div>}
                </div>
                <div className="entry-tags">
                  {(d.tags || []).slice(0, 3).map((t) => (
                    <span className="minitag" key={t}>{t}</span>
                  ))}
                </div>
                <div className="entry-date">{FlytStore.relTime(d.updated)}</div>
              </div>
            ))}
            {filtered.length === 0 && (
              <div className="empty">
                <Icon name="doc-lines" size={26} stroke={1.3}/>
                <div className="empty-title">{q || activeTag ? "Nothing matches" : "No documents yet"}</div>
                <div className="empty-sub">
                  {q || activeTag ? "Try a different search or tag." : "Create your first document to begin."}
                </div>
                {!q && !activeTag && <button className="btn-ink" style={{ marginTop: 14 }} onClick={onNew}><Icon name="plus" size={14}/><span>Create document</span></button>}
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="statusbar">
        <span><Icon name="folder" size={12} style={{ verticalAlign: -2, marginRight: 6 }}/>{vaultPath}</span>
        <span className="sep">·</span>
        <span>{docs.length} {docs.length === 1 ? "file" : "files"}</span>
        <span style={{ flex: 1 }}/>
        <span className="hintline"><Kbd>⌘K</Kbd> to search or run a command</span>
      </div>
    </div>
  );
};

window.HomeView = HomeView;
