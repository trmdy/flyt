// flyt — Document view: inline title/filename, tags, live markdown editor.

const TOOLBAR_ACTIONS = ["bold", "italic", "strike", "code", "|", "link", "list", "quote"];

// ---- inline single-line editable field -------------------------------------
const InlineField = ({ value, onInput, onEnter, className, placeholder, sanitize }) => {
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (ref.current && ref.current.textContent !== value) ref.current.textContent = value || "";
  }, [value]);
  return (
    <div
      ref={ref}
      className={className}
      contentEditable
      suppressContentEditableWarning
      spellCheck={false}
      data-placeholder={placeholder}
      onInput={(e) => {
        let v = e.currentTarget.textContent;
        if (sanitize) v = sanitize(v);
        onInput(v);
      }}
      onKeyDown={(e) => {
        if (e.key === "Enter") { e.preventDefault(); onEnter && onEnter(); }
      }}
      onPaste={(e) => {
        e.preventDefault();
        const text = (e.clipboardData || window.clipboardData).getData("text").replace(/\n/g, " ");
        document.execCommand("insertText", false, text);
      }}
    />
  );
};

// ---- tag editor -------------------------------------------------------------
const TagEditor = ({ tags, allTags, onChange }) => {
  const [input, setInput] = React.useState("");
  const [open, setOpen] = React.useState(false);
  const wrapRef = React.useRef(null);

  const add = (t) => {
    const v = (t || "").trim().toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, "");
    if (v && !tags.includes(v)) onChange([...tags, v]);
    setInput("");
    setOpen(false);
  };
  const remove = (t) => onChange(tags.filter((x) => x !== t));

  const suggestions = allTags
    .filter((s) => !tags.includes(s.tag) && (!input || s.tag.includes(input.toLowerCase())))
    .slice(0, 6);
  const showCreate = input.trim() && !allTags.some((s) => s.tag === input.trim().toLowerCase()) && !tags.includes(input.trim().toLowerCase());

  React.useEffect(() => {
    const close = (e) => { if (wrapRef.current && !wrapRef.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", close);
    return () => document.removeEventListener("mousedown", close);
  }, []);

  return (
    <div className="tag-editor" ref={wrapRef}>
      {tags.map((t) => (
        <span className="tag-chip" key={t}>
          <span>{t}</span>
          <button onClick={() => remove(t)} aria-label={"Remove " + t}><Icon name="x" size={10} stroke={2}/></button>
        </span>
      ))}
      <div className="tag-add">
        <span className="tag-hash">#</span>
        <input
          value={input}
          onChange={(e) => { setInput(e.target.value); setOpen(true); }}
          onFocus={() => setOpen(true)}
          placeholder={tags.length ? "add tag" : "add a tag…"}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === ",") { e.preventDefault(); add(input); }
            else if (e.key === "Backspace" && !input && tags.length) remove(tags[tags.length - 1]);
            else if (e.key === "Escape") setOpen(false);
          }}
        />
        {open && (suggestions.length > 0 || showCreate) && (
          <div className="tag-pop">
            {suggestions.map((s) => (
              <div className="tag-pop-item" key={s.tag} onMouseDown={(e) => { e.preventDefault(); add(s.tag); }}>
                <Icon name="tag" size={12}/><span>{s.tag}</span><span className="tag-pop-count">{s.count}</span>
              </div>
            ))}
            {showCreate && (
              <div className="tag-pop-item create" onMouseDown={(e) => { e.preventDefault(); add(input); }}>
                <Icon name="plus" size={12}/><span>Create “{input.trim().toLowerCase()}”</span>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

// ---- live markdown editor body ---------------------------------------------
const LiveEditor = ({ initialHtml, onChange, proseSize, width, showTokens }) => {
  const ref = React.useRef(null);
  const [empty, setEmpty] = React.useState(!initialHtml || !initialHtml.trim());

  React.useEffect(() => {
    if (ref.current) ref.current.innerHTML = initialHtml || "";
  }, []); // mount only (component is keyed by doc id)

  const report = () => {
    const html = ref.current ? ref.current.innerHTML : "";
    setEmpty(!ref.current || ref.current.textContent.trim() === "");
    onChange(html);
  };

  return (
    <div className="editor-body-wrap">
      <div
        ref={ref}
        className={"doc doc-body" + (showTokens ? " show-tokens" : "")}
        contentEditable
        suppressContentEditableWarning
        spellCheck={true}
        style={{ fontSize: proseSize, maxWidth: width }}
        onInput={() => { mdEdit.inlineShortcuts(ref.current); report(); }}
        onKeyDown={(e) => {
          if (e.key === " ") { if (mdEdit.blockShortcutOnSpace(ref.current)) { e.preventDefault(); report(); } }
          else if (e.key === "Enter" && !e.shiftKey) { if (mdEdit.enterFromBlock(ref.current, e)) report(); }
          else if ((e.metaKey || e.ctrlKey) && !e.shiftKey && e.key.toLowerCase() === "b") { e.preventDefault(); mdEdit.FORMATTERS.bold(); report(); }
          else if ((e.metaKey || e.ctrlKey) && !e.shiftKey && e.key.toLowerCase() === "i") { e.preventDefault(); mdEdit.FORMATTERS.italic(); report(); }
          else if ((e.metaKey || e.ctrlKey) && !e.shiftKey && e.key.toLowerCase() === "e") { e.preventDefault(); mdEdit.FORMATTERS.code(); report(); }
          else if ((e.metaKey || e.ctrlKey) && e.shiftKey && e.key.toLowerCase() === "x") { e.preventDefault(); mdEdit.FORMATTERS.strike(); report(); }
        }}
      />
      {empty && (
        <div className="editor-placeholder" style={{ fontSize: proseSize, maxWidth: width }}>
          Start writing. Type <span className="mono-hint"># </span> for a heading, <span className="mono-hint">- </span> for a list, <span className="mono-hint">**bold**</span>…
        </div>
      )}
    </div>
  );
};

// ---- document view ----------------------------------------------------------
const DocumentView = ({ doc, vaultPath, allTags, onBack, onPatch, onDelete, tweaks }) => {
  const editorRef = React.useRef(null);
  const [liveHtml, setLiveHtml] = React.useState(doc.html);
  const [savedAt, setSavedAt] = React.useState(doc.updated);
  const saveTimer = React.useRef(null);
  const titleRef = React.useRef(null);

  // focus title on a brand-new (empty) doc
  React.useEffect(() => {
    if (!doc.title && !doc.html && titleRef.current) {
      const el = titleRef.current.querySelector(".doc-title");
      if (el) el.focus();
    }
  }, [doc.id]);

  const commitHtml = (html) => {
    setLiveHtml(html);
    clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => {
      onPatch({ html });
      setSavedAt(Date.now());
    }, 350);
  };

  const onTitle = (title) => {
    const patch = { title };
    if (!doc.filenameEdited) patch.filename = FlytStore.slugify(title);
    onPatch(patch);
  };
  const onFilename = (filename) => onPatch({ filename, filenameEdited: true });

  const words = FlytStore.wordCount(liveHtml);
  const fname = (doc.filename || "untitled") + ".md";

  return (
    <div className="flyt">
      <div className="appbar">
        <button className="iconbtn" onClick={onBack} title="Back to library" aria-label="Back"><Icon name="arrow-left" size={17}/></button>
        <div className="crumb">
          <Icon name="folder" size={13}/>
          <span className="crumb-vault">{vaultPath.split("/").pop()}</span>
          <Icon name="chevron-right" size={12} style={{ color: "var(--ink-4)" }}/>
          <span className="crumb-file">{fname}</span>
        </div>
        <div style={{ flex: 1 }}/>
        <button className="iconbtn danger" onClick={onDelete} title="Delete document" aria-label="Delete"><Icon name="trash" size={16}/></button>
      </div>

      <div className="editor-stage">
        <div className="editor-col" style={{ maxWidth: tweaks.width }} ref={titleRef}>
          <InlineField className="doc-title" value={doc.title} placeholder="Untitled"
            onInput={onTitle}
            onEnter={() => { const b = editorRef.current; if (b) { b.focus(); mdEdit && null; } }}/>

          <div className="doc-filename-row">
            <Icon name="file-md" size={13}/>
            <InlineField className="doc-filename" value={doc.filename} placeholder="filename"
              sanitize={(v) => v.toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, "")}
              onInput={onFilename}/>
            <span className="doc-ext">.md</span>
          </div>

          <TagEditor tags={doc.tags || []} allTags={allTags} onChange={(tags) => onPatch({ tags })}/>

          <div className="doc-rule"/>

          <div ref={(el) => { if (el) editorRef.current = el.querySelector(".doc-body"); }}>
            <LiveEditor
              key={doc.id}
              initialHtml={doc.html}
              onChange={commitHtml}
              proseSize={tweaks.proseSize}
              width={tweaks.width}
              showTokens={tweaks.showTokens}
            />
          </div>
        </div>
      </div>

      <SelectionToolbar editorRef={editorRef} actions={TOOLBAR_ACTIONS} onCommit={() => { if (editorRef.current) commitHtml(editorRef.current.innerHTML); }}/>

      <div className="statusbar">
        <span className="live">saved · {FlytStore.relTime(savedAt)}</span>
        <span className="sep">·</span>
        <span>{words} {words === 1 ? "word" : "words"}</span>
        <span className="sep">·</span>
        <span className="path-mono">{vaultPath}/{fname}</span>
        <span style={{ flex: 1 }}/>
        <span className="hintline"><Kbd>⌘C</Kbd><Kbd>⌘C</Kbd> copy doc · <Kbd>⇧⌘C</Kbd><Kbd>⇧⌘C</Kbd> copy path</span>
      </div>
    </div>
  );
};

window.DocumentView = DocumentView;
