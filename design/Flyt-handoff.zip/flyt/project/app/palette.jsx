// flyt — ⌘K command palette: action list + document search.

const CommandPalette = ({ docs, inDoc, onClose, onOpen, onNew, onHome, onSettings, onCopyDoc, onCopyPath }) => {
  const [query, setQuery] = React.useState("");
  const [sel, setSel] = React.useState(0);
  const inputRef = React.useRef(null);
  const listRef = React.useRef(null);

  React.useEffect(() => { inputRef.current && inputRef.current.focus(); }, []);

  const actions = [
    { id: "new", icon: "plus", label: "New document", meta: "⌘N", run: onNew },
    inDoc && { id: "copy-doc", icon: "copy", label: "Copy entire document", meta: "⌘C ⌘C", run: onCopyDoc },
    inDoc && { id: "copy-path", icon: "folder", label: "Copy path in vault", meta: "⇧⌘C ⇧⌘C", run: onCopyPath },
    inDoc && { id: "home", icon: "arrow-left", label: "Back to library", run: onHome },
    { id: "settings", icon: "settings", label: "Vault settings…", run: onSettings },
  ].filter(Boolean);

  const q = query.trim().toLowerCase();
  const fActions = actions.filter((a) => !q || a.label.toLowerCase().includes(q));
  const fDocs = docs
    .filter((d) => {
      if (!q) return true;
      return (d.title + " " + (d.tags || []).join(" ") + " " + FlytStore.previewText(d.html)).toLowerCase().includes(q);
    })
    .sort((a, b) => b.updated - a.updated)
    .slice(0, 8)
    .map((d) => ({ id: "doc-" + d.id, icon: "file-md", label: d.title || "Untitled", sub: (d.tags || [])[0], meta: FlytStore.relTime(d.updated), run: () => onOpen(d.id) }));

  const flat = [...fActions, ...fDocs];
  const clamped = Math.min(sel, Math.max(0, flat.length - 1));

  React.useEffect(() => { setSel(0); }, [query]);
  React.useEffect(() => {
    const el = listRef.current && listRef.current.querySelector(".palette-item.active");
    if (el) el.scrollIntoView ? el.scrollIntoView({ block: "nearest" }) : null;
  }, [clamped]);

  const exec = (item) => { if (item) { onClose(); setTimeout(() => item.run(), 0); } };

  const onKey = (e) => {
    if (e.key === "ArrowDown") { e.preventDefault(); setSel((s) => Math.min(s + 1, flat.length - 1)); }
    else if (e.key === "ArrowUp") { e.preventDefault(); setSel((s) => Math.max(s - 1, 0)); }
    else if (e.key === "Enter") { e.preventDefault(); exec(flat[clamped]); }
    else if (e.key === "Escape") { e.preventDefault(); onClose(); }
  };

  let idx = -1;
  const renderItem = (item) => {
    idx += 1;
    const myIdx = idx;
    return (
      <div
        key={item.id}
        className={"palette-item" + (myIdx === clamped ? " active" : "")}
        onMouseEnter={() => setSel(myIdx)}
        onClick={() => exec(item)}
      >
        <span className="ico" style={{ width: 16, justifyContent: "center", display: "flex" }}><Icon name={item.icon} size={14}/></span>
        <span>{item.label}</span>
        {item.sub && <span className="sub">#{item.sub}</span>}
        <span className="meta">{item.meta || ""}</span>
      </div>
    );
  };

  return (
    <div className="scrim" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="palette" onKeyDown={onKey}>
        <div className="palette-input">
          <Icon name="search" size={15} style={{ color: "var(--ink-3)" }}/>
          <input ref={inputRef} value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search documents or run a command…"/>
          <Kbd>esc</Kbd>
        </div>
        <div className="palette-list" ref={listRef}>
          {fActions.length > 0 && <div className="palette-section-label">Actions</div>}
          {fActions.map(renderItem)}
          {fDocs.length > 0 && <div className="palette-section-label">Documents</div>}
          {fDocs.map(renderItem)}
          {flat.length === 0 && <div className="palette-empty">No matches for “{query}”</div>}
        </div>
        <div className="palette-foot">
          <span className="hint"><Kbd>↑↓</Kbd> navigate</span>
          <span className="hint"><Kbd>↵</Kbd> select</span>
          <span style={{ marginLeft: "auto", color: "var(--ink-3)" }}>{flat.length} result{flat.length === 1 ? "" : "s"}</span>
        </div>
      </div>
    </div>
  );
};

window.CommandPalette = CommandPalette;
