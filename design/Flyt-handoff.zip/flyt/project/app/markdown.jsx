// flyt — live markdown editing helpers + floating selection toolbar.
// The editor is a single contentEditable. Block-level markdown shortcuts
// transform the current block on space; inline shortcuts convert **bold**,
// *italic*, `code`, ~~strike~~, [text](url) as you close the delimiter.

// ---- low-level range helpers ------------------------------------------------
function getBlock(editor, node) {
  let n = node;
  while (n && n.parentNode !== editor) n = n.parentNode;
  return n && n.parentNode === editor ? n : null;
}

function placeCaretAtStart(el) {
  const r = document.createRange();
  r.selectNodeContents(el);
  r.collapse(true);
  const sel = window.getSelection();
  sel.removeAllRanges();
  sel.addRange(r);
}

function textBeforeCaret(block, range) {
  const r = document.createRange();
  r.selectNodeContents(block);
  r.setEnd(range.startContainer, range.startOffset);
  return r.toString();
}

function caretAtEnd(block, range) {
  const r = document.createRange();
  r.selectNodeContents(block);
  r.setStart(range.endContainer, range.endOffset);
  return r.toString().length === 0;
}

function removeLeadingChars(block, n) {
  let node = block;
  while (node && node.nodeType !== 3) node = node.firstChild;
  if (node) node.nodeValue = node.nodeValue.slice(n);
}

function replaceBlockTag(block, tag) {
  const el = document.createElement(tag);
  while (block.firstChild) el.appendChild(block.firstChild);
  if (!el.firstChild) el.appendChild(document.createElement("br"));
  block.replaceWith(el);
  return el;
}

// ---- block shortcuts (call on space keydown; returns true if handled) -------
function blockShortcutOnSpace(editor) {
  const sel = window.getSelection();
  if (!sel.rangeCount) return false;
  const range = sel.getRangeAt(0);
  if (!range.collapsed) return false;
  const block = getBlock(editor, range.startContainer);
  if (!block) return false;
  const tag = block.tagName.toLowerCase();
  if (tag === "li" || tag === "ul" || tag === "blockquote") return false;
  const pre = textBeforeCaret(block, range);

  if (pre === "-" || pre === "*") {
    removeLeadingChars(block, 1);
    const li = document.createElement("li");
    while (block.firstChild) li.appendChild(block.firstChild);
    if (!li.firstChild) li.appendChild(document.createElement("br"));
    const ul = document.createElement("ul");
    ul.appendChild(li);
    block.replaceWith(ul);
    placeCaretAtStart(li);
    return true;
  }
  const map = { "#": "h1", "##": "h2", "###": "h3", ">": "blockquote" };
  if (map[pre]) {
    removeLeadingChars(block, pre.length);
    const el = replaceBlockTag(block, map[pre]);
    placeCaretAtStart(el);
    return true;
  }
  return false;
}

// ---- inline shortcuts (call on input) ---------------------------------------
const INLINE_PATTERNS = [
  { re: /\*\*([^*]+)\*\*$/, tag: "strong", content: 1, lead: 0 },
  { re: /~~([^~]+)~~$/, tag: "s", content: 1, lead: 0 },
  { re: /`([^`]+)`$/, tag: "code", content: 1, lead: 0 },
  { re: /\[([^\]]+)\]\(([^)]+)\)$/, tag: "a", content: 1, href: 2, lead: 0 },
  { re: /(^|[^*])\*([^*\s][^*]*)\*$/, tag: "em", content: 2, lead: 1 },
];

function inlineShortcuts(editor) {
  const sel = window.getSelection();
  if (!sel.rangeCount) return false;
  const range = sel.getRangeAt(0);
  if (!range.collapsed) return false;
  const node = range.startContainer;
  if (node.nodeType !== 3) return false;
  const offset = range.startOffset;
  const text = node.nodeValue.slice(0, offset);

  for (const p of INLINE_PATTERNS) {
    const m = text.match(p.re);
    if (!m) continue;
    const full = m[0];
    const leadLen = p.lead ? m[p.lead].length : 0;
    const matchStart = offset - full.length + leadLen;
    const removeLen = full.length - leadLen;
    const after = node.splitText(matchStart);
    after.nodeValue = after.nodeValue.slice(removeLen);
    const el = document.createElement(p.tag);
    el.textContent = m[p.content];
    if (p.href) el.setAttribute("href", m[p.href]);
    node.parentNode.insertBefore(el, after);
    const r = document.createRange();
    r.setStart(after, 0);
    r.collapse(true);
    sel.removeAllRanges();
    sel.addRange(r);
    return true;
  }
  return false;
}

// ---- enter after heading/quote drops to a paragraph -------------------------
function enterFromBlock(editor, e) {
  const sel = window.getSelection();
  if (!sel.rangeCount) return false;
  const range = sel.getRangeAt(0);
  const block = getBlock(editor, range.startContainer);
  if (!block) return false;
  const tag = block.tagName.toLowerCase();
  if (["h1", "h2", "h3", "blockquote"].includes(tag) && caretAtEnd(block, range)) {
    e.preventDefault();
    const p = document.createElement("p");
    p.appendChild(document.createElement("br"));
    block.after(p);
    placeCaretAtStart(p);
    return true;
  }
  return false;
}

// ---- inline formatting commands (used by the selection toolbar) -------------
function wrapSelection(tag, attrs) {
  const sel = window.getSelection();
  if (!sel.rangeCount || sel.isCollapsed) return;
  const range = sel.getRangeAt(0);
  const el = document.createElement(tag);
  if (attrs) Object.entries(attrs).forEach(([k, v]) => el.setAttribute(k, v));
  try {
    range.surroundContents(el);
  } catch (e) {
    const frag = range.extractContents();
    el.appendChild(frag);
    range.insertNode(el);
  }
  const r = document.createRange();
  r.selectNodeContents(el);
  sel.removeAllRanges();
  sel.addRange(r);
}

const FORMATTERS = {
  bold: () => document.execCommand("bold"),
  italic: () => document.execCommand("italic"),
  strike: () => document.execCommand("strikeThrough"),
  list: () => document.execCommand("insertUnorderedList"),
  quote: () => document.execCommand("formatBlock", false, "blockquote"),
  code: () => wrapSelection("code"),
  link: () => wrapSelection("a", { href: "#" }),
};

// ---- floating selection toolbar ---------------------------------------------
const ICON_ACTIONS = {
  bold: { glyph: <span style={{ fontWeight: 700 }}>B</span>, label: "Bold", sc: "⌘B" },
  italic: { glyph: <span style={{ fontStyle: "italic", fontFamily: "var(--prose)" }}>I</span>, label: "Italic", sc: "⌘I" },
  strike: { glyph: <span style={{ textDecoration: "line-through" }}>S</span>, label: "Strikethrough", sc: "⌘⇧X" },
  code: { glyph: <span style={{ fontFamily: "var(--mono)", fontSize: 12 }}>{"</>"}</span>, label: "Code", sc: "⌘E" },
  link: { icon: "link", label: "Link" },
  list: { glyph: <span style={{ fontFamily: "var(--mono)", fontSize: 13, lineHeight: 1 }}>•—</span>, label: "Bullet list" },
  quote: { glyph: <span style={{ fontFamily: "var(--prose)", fontSize: 18, lineHeight: 1, position: "relative", top: -1 }}>&ldquo;</span>, label: "Quote" },
};

const SelectionToolbar = ({ editorRef, onCommit, actions }) => {
  const [pos, setPos] = React.useState(null);
  const barRef = React.useRef(null);

  const update = React.useCallback(() => {
    const editor = editorRef.current;
    const sel = window.getSelection();
    if (!editor || !sel || sel.rangeCount === 0 || sel.isCollapsed) { setPos(null); return; }
    const anchor = sel.anchorNode;
    if (!anchor || !editor.contains(anchor)) { setPos(null); return; }
    const rect = sel.getRangeAt(0).getBoundingClientRect();
    if (rect.width === 0 && rect.height === 0) { setPos(null); return; }
    setPos({ top: rect.bottom + 9, left: rect.left + rect.width / 2 });
  }, [editorRef]);

  React.useEffect(() => {
    const onSel = () => update();
    document.addEventListener("selectionchange", onSel);
    window.addEventListener("scroll", onSel, true);
    window.addEventListener("resize", onSel);
    return () => {
      document.removeEventListener("selectionchange", onSel);
      window.removeEventListener("scroll", onSel, true);
      window.removeEventListener("resize", onSel);
    };
  }, [update]);

  if (!pos) return null;

  let left = pos.left;
  const bw = barRef.current ? barRef.current.offsetWidth : 240;
  left = Math.max(bw / 2 + 12, Math.min(left, window.innerWidth - bw / 2 - 12));

  const run = (key) => {
    const editor = editorRef.current;
    if (editor) editor.focus();
    FORMATTERS[key] && FORMATTERS[key]();
    onCommit && onCommit();
    setTimeout(update, 0);
  };

  return (
    <div
      ref={barRef}
      className="selection-toolbar"
      style={{ position: "fixed", top: pos.top, left, transform: "translateX(-50%)" }}
      onMouseDown={(e) => e.preventDefault()}
    >
      {actions.map((key, i) => {
        if (key === "|") return <span className="st-divider" key={"d" + i}/>;
        const a = ICON_ACTIONS[key];
        if (!a) return null;
        return (
          <button
            key={key}
            className="st-btn"
            title={a.sc ? `${a.label} · ${a.sc}` : a.label}
            aria-label={a.label}
            onClick={() => run(key)}
          >
            {a.icon ? <Icon name={a.icon} size={13} stroke={1.6}/> : <span className="st-glyph">{a.glyph}</span>}
          </button>
        );
      })}
      <div className="st-arrow"/>
    </div>
  );
};

window.mdEdit = { blockShortcutOnSpace, inlineShortcuts, enterFromBlock, FORMATTERS };
window.SelectionToolbar = SelectionToolbar;
