// flyt — vault store (plain JS, window.FlytStore)
// A working, persistent vault backed by localStorage. Documents store their
// body as HTML (the editor's native format); markdown is derived on demand.

(function () {
  const LS_KEY = "flyt.vault.v1";

  const slugify = (s) =>
    (s || "untitled")
      .toLowerCase()
      .trim()
      .replace(/['"]/g, "")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 60) || "untitled";

  const uid = () => "d" + Math.random().toString(36).slice(2, 9);

  // ---- markdown helpers ----------------------------------------------------
  // HTML (editor content) -> markdown string
  function htmlToMarkdown(html) {
    const root = document.createElement("div");
    root.innerHTML = html || "";

    const inline = (node) => {
      let out = "";
      node.childNodes.forEach((n) => {
        if (n.nodeType === 3) {
          out += n.nodeValue;
        } else if (n.nodeType === 1) {
          const tag = n.tagName.toLowerCase();
          const inner = inline(n);
          if (tag === "strong" || tag === "b") out += `**${inner}**`;
          else if (tag === "em" || tag === "i") out += `*${inner}*`;
          else if (tag === "s" || tag === "del" || tag === "strike") out += `~~${inner}~~`;
          else if (tag === "code") out += "`" + inner + "`";
          else if (tag === "a") out += `[${inner}](${n.getAttribute("href") || "#"})`;
          else if (tag === "br") out += "\n";
          else out += inner;
        }
      });
      return out;
    };

    const lines = [];
    root.childNodes.forEach((n) => {
      if (n.nodeType !== 1) {
        const t = (n.nodeValue || "").trim();
        if (t) lines.push(t, "");
        return;
      }
      const tag = n.tagName.toLowerCase();
      if (tag === "h1") lines.push("# " + inline(n), "");
      else if (tag === "h2") lines.push("## " + inline(n), "");
      else if (tag === "h3") lines.push("### " + inline(n), "");
      else if (tag === "blockquote") {
        inline(n).split("\n").forEach((l) => lines.push("> " + l));
        lines.push("");
      } else if (tag === "ul") {
        n.querySelectorAll(":scope > li").forEach((li) => lines.push("- " + inline(li)));
        lines.push("");
      } else if (tag === "ol") {
        let i = 1;
        n.querySelectorAll(":scope > li").forEach((li) => lines.push(`${i++}. ` + inline(li)));
        lines.push("");
      } else if (tag === "pre") {
        lines.push("```", n.textContent, "```", "");
      } else if (tag === "hr") {
        lines.push("---", "");
      } else {
        const t = inline(n);
        lines.push(t, "");
      }
    });
    return lines.join("\n").replace(/\n{3,}/g, "\n\n").trim() + "\n";
  }

  // markdown string -> editor HTML (used to seed docs)
  function markdownToHtml(md) {
    const linesArr = (md || "").replace(/\r/g, "").split("\n");
    const out = [];
    let i = 0;
    const inlineMd = (s) =>
      s
        .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
        .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
        .replace(/(^|[^*])\*([^*\n]+)\*/g, "$1<em>$2</em>")
        .replace(/~~([^~]+)~~/g, "<s>$1</s>")
        .replace(/`([^`]+)`/g, "<code>$1</code>")
        .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2">$1</a>');
    while (i < linesArr.length) {
      const line = linesArr[i];
      if (/^###\s+/.test(line)) { out.push(`<h3>${inlineMd(line.replace(/^###\s+/, ""))}</h3>`); i++; }
      else if (/^##\s+/.test(line)) { out.push(`<h2>${inlineMd(line.replace(/^##\s+/, ""))}</h2>`); i++; }
      else if (/^#\s+/.test(line)) { out.push(`<h1>${inlineMd(line.replace(/^#\s+/, ""))}</h1>`); i++; }
      else if (/^>\s?/.test(line)) {
        const buf = [];
        while (i < linesArr.length && /^>\s?/.test(linesArr[i])) { buf.push(inlineMd(linesArr[i].replace(/^>\s?/, ""))); i++; }
        out.push(`<blockquote>${buf.join("<br>")}</blockquote>`);
      } else if (/^[-*]\s+/.test(line)) {
        const buf = [];
        while (i < linesArr.length && /^[-*]\s+/.test(linesArr[i])) { buf.push(`<li>${inlineMd(linesArr[i].replace(/^[-*]\s+/, ""))}</li>`); i++; }
        out.push(`<ul>${buf.join("")}</ul>`);
      } else if (/^\s*$/.test(line)) { i++; }
      else { out.push(`<p>${inlineMd(line)}</p>`); i++; }
    }
    return out.join("\n");
  }

  const wordCount = (html) => {
    const tmp = document.createElement("div");
    tmp.innerHTML = html || "";
    const t = (tmp.textContent || "").trim();
    return t ? t.split(/\s+/).length : 0;
  };

  const previewText = (html) => {
    const tmp = document.createElement("div");
    tmp.innerHTML = html || "";
    // skip the first heading; use following body text
    const firstP = tmp.querySelector("p, li, blockquote");
    const t = (firstP ? firstP.textContent : tmp.textContent || "").trim();
    return t.replace(/\s+/g, " ").slice(0, 200);
  };

  // ---- seed -----------------------------------------------------------------
  function seed() {
    const now = Date.now();
    const mk = (id, title, filename, tags, md, ago) => ({
      id,
      title,
      filename,
      filenameEdited: true,
      tags,
      html: markdownToHtml(md),
      created: now - ago,
      updated: now - ago,
    });
    const docs = [
      mk("agent-streaming-protocol", "Agent streaming protocol", "agent-streaming-protocol", ["spec", "engineering"],
`Define the streaming contract between the editor host and a remote model. Tokens arrive over a server-sent event stream; the host owns reconciliation against the in-memory document, persistence to disk, and visible UI state.

The editor is the source of truth. Agents propose; humans dispose. Anywhere we make this asymmetric, we get it wrong.

## Goals

- Streaming feels live, never spinning.
- Disk persistence never blocks input.
- Small in-place edits are reversible with a single keystroke.

## Non-goals

- Multi-agent orchestration. One model, one stream.
- Conflict resolution across collaborators. Single writer for v1.`, 1000 * 60 * 8),
      mk("q3-product-bets", "Q3 product bets", "q3-product-bets", ["plan", "product"],
`Three things we're committing to this quarter.

## The bets

- A durable thinking surface that outlives any single session.
- A native agent runtime, not a chat bolt-on.
- Files on disk as the single source of truth.

Each bet has one owner and one metric. If we can't name both, it isn't a bet yet — it's a wish.`, 1000 * 60 * 60 * 5),
      mk("interview-aria", "Interview — Aria, founding designer", "interview-aria", ["note", "research"],
`Background in editorial systems. Worked on the type stack at a reading app. Has strong opinions on prose width and trailing whitespace.

> "A writing tool should disappear. The moment you notice the interface, it has failed."

Key takeaways: keep the column narrow, lean on the serif, and never animate the caret region while the user is typing.`, 1000 * 60 * 60 * 26),
      mk("positioning", "Positioning — flyt is not a chat app", "positioning", ["brief", "product"],
`We keep getting compared to chat-first tools. That's the wrong reference class.

flyt is a *writing tool* that happens to have an agent. The document is the artifact. The conversation, if any, is scaffolding you throw away.

## What we are

- A clean desk for durable thinking.
- File-first, local-first, fast.

## What we are not

- A thread you scroll forever.
- A place where the AI writes and you watch.`, 1000 * 60 * 60 * 27),
      mk("filename-conventions", "Filename + vault conventions", "filename-conventions", ["spec"],
`Each entry is a markdown file inside the vault. The filename is the slugified title at creation time, but the two are decoupled after that — rename either freely.

The vault is a single configurable folder. Pointing flyt at a new folder migrates every document to the new location.

## Rules

- Title is for humans; filename is for the filesystem.
- Tags are metadata, never folders.`, 1000 * 60 * 60 * 24 * 3),
      mk("onboarding-first-doc", "Onboarding — the first document", "onboarding-first-doc", ["brief", "product"],
`The first thirty seconds are everything. New users land on an empty editor that already contains a single sentence inviting them to write.

No setup. No account wall. No empty-state illustration. Just a caret and a warm page.`, 1000 * 60 * 60 * 24 * 6),
    ];
    return { vaultPath: "~/Documents/flyt", docs };
  }

  // ---- persistence ----------------------------------------------------------
  function load() {
    try {
      const raw = localStorage.getItem(LS_KEY);
      if (raw) return JSON.parse(raw);
    } catch (e) {}
    const s = seed();
    save(s);
    return s;
  }
  function save(state) {
    try { localStorage.setItem(LS_KEY, JSON.stringify(state)); } catch (e) {}
  }

  function newDoc(existing) {
    return {
      id: uid(),
      title: "",
      filename: "",
      filenameEdited: false,
      tags: [],
      html: "",
      created: Date.now(),
      updated: Date.now(),
    };
  }

  function allTags(docs) {
    const set = new Map();
    docs.forEach((d) => (d.tags || []).forEach((t) => set.set(t, (set.get(t) || 0) + 1)));
    return [...set.entries()].sort((a, b) => b[1] - a[1]).map(([t, n]) => ({ tag: t, count: n }));
  }

  function relTime(ts) {
    const diff = Date.now() - ts;
    const m = Math.floor(diff / 60000);
    if (m < 1) return "just now";
    if (m < 60) return m + "m ago";
    const h = Math.floor(m / 60);
    if (h < 24) return h + "h ago";
    const d = Math.floor(h / 24);
    if (d === 1) return "yesterday";
    if (d < 7) return d + "d ago";
    const date = new Date(ts);
    return date.toLocaleDateString(undefined, { month: "short", day: "numeric" });
  }

  window.FlytStore = {
    load, save, seed, newDoc, slugify, uid,
    htmlToMarkdown, markdownToHtml, wordCount, previewText, allTags, relTime,
  };
})();
