// flyt — Agent streaming inline at the cursor
// No side panel. The agent writes directly into the document below the writer's
// caret as ghost text. A small presence indicator pinned to the editor signals
// when the agent is here, ready, or generating.

const streamPara1 = "The contract has three layers. The transport — a server-sent event stream that yields token deltas, plus structured events for status, citations, and tool calls. The reducer — a function that maps a stream of deltas into Slate operations against the in-memory document. And the surface — the small set of UI states the writer ever has to think about, which is exactly three: ready, generating, ready-to-accept.";

const useTypewriter = (target, charsPerTick = 6, tickMs = 30) => {
  const [pos, setPos] = React.useState(0);
  React.useEffect(() => {
    if (pos >= target.length) return;
    const id = setTimeout(() => setPos(p => Math.min(target.length, p + charsPerTick)), tickMs);
    return () => clearTimeout(id);
  }, [pos, target.length, charsPerTick, tickMs]);
  return [target.slice(0, pos), pos >= target.length];
};

const streamPara2 = "Reversibility is the load-bearing constraint. Every accepted draft is a single Slate operation, applied at the current selection. Undo reverses it atomically. Esc";

// Presence indicator — pinned to the editor, pulses gently when generating.
const Presence = ({ state = "generating", model = "haiku-4-5" }) => {
  const label = state === "generating" ? "generating" : state === "ready" ? "ready" : state;
  return (
    <div className={"presence presence-" + state}>
      <span className="presence-dot"/>
      <span className="presence-model">{model}</span>
      <span className="presence-sep">·</span>
      <span className="presence-state">{label}</span>
    </div>
  );
};

// Inline action chip — sits at the end of the streaming block while it generates.
const StreamActions = ({ complete }) => {
  if (complete) {
    return (
      <div className="stream-actions">
        <span className="sa-meta">487 tokens · 2.1s</span>
        <span className="sa-sep">·</span>
        <span>generated below your caret</span>
        <span className="sa-spacer"/>
        <button className="sa-btn"><Icon name="x" size={11}/><span>Discard</span></button>
        <button className="sa-btn primary">
          <Icon name="check" size={11}/>
          <span>Accept</span>
          <Kbd style={{ marginLeft: 4 }}>Tab</Kbd>
        </button>
      </div>
    );
  }
  return (
    <div className="stream-actions">
      <span className="sa-pulse"/>
      <span className="sa-meta">streaming · 312 tokens</span>
      <span className="sa-sep">·</span>
      <span>writing into your document</span>
      <span className="sa-spacer"/>
      <button className="sa-btn"><Icon name="stop" size={11}/><span>Stop</span><Kbd style={{ marginLeft: 4 }}>Esc</Kbd></button>
    </div>
  );
};

const StreamingScreen = () => {
  const full = streamPara1 + "\n\n" + streamPara2;
  const [out, complete] = useTypewriter(full, 5, 28);

  // segment the output into two paragraphs visually
  const splitIdx = out.indexOf("\n\n");
  const p1 = splitIdx === -1 ? out : out.slice(0, splitIdx);
  const p2 = splitIdx === -1 ? "" : out.slice(splitIdx + 2);

  return (
    <div className="flyt">
      <WinChrome title="agent-streaming-protocol/index.md"/>
      <div style={{ display: "flex", flex: "1 1 auto", minHeight: 0 }}>
        <RecentsSidebar active={0}/>

        <main className="main">
          <div className="topbar">
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <button className="btn-quiet" style={{ padding: 4 }}>
                <Icon name="sidebar" size={14}/>
              </button>
              <span style={{ fontFamily: "var(--mono)", fontSize: 11.5, color: "var(--ink-3)" }}>Product</span>
              <Icon name="chevron-right" size={11} style={{ color: "var(--ink-4)" }}/>
              <span style={{ fontFamily: "var(--mono)", fontSize: 11.5, color: "var(--ink-2)" }}>agent-streaming-protocol</span>
            </div>
            <div style={{ flex: 1 }}/>
            <button className="btn-quiet"><Icon name="sparkles" size={13}/><span>Ask</span><Kbd>⌘J</Kbd></button>
          </div>

          <div className="editor-stage" style={{ padding: "56px 40px 140px" }}>
            <div className="editor-col">
              <h1 style={{
                fontFamily: "var(--prose)", fontSize: 38, lineHeight: 1.15,
                margin: "0 0 6px", fontWeight: 500, letterSpacing: "-0.015em"
              }}>Agent streaming protocol</h1>
              <div className="doc-meta">
                <span>Spec</span><span className="dot"/><span>edited just now</span>
              </div>

              <div className="doc">
                <p>Define the streaming contract between the editor host and a remote model. Tokens arrive over a server-sent event stream; the host owns reconciliation against the in-memory document, persistence to disk, and visible UI state.</p>

                <h2>Surface area</h2>

                {/* committed prose */}
                <p>The editor is the source of truth. Agents propose; humans dispose. We hold this asymmetric: any time an agent would mutate the document without a draft, we route it through a draft instead.</p>

                {/* streaming inline — ghost-styled prose followed by trailing caret + action chip */}
                <div className="stream-block">
                  <p className="ghost-prose">
                    {p1}
                    {splitIdx === -1 && !complete && <span className="ghost-caret"/>}
                  </p>
                  {p2 !== "" && (
                    <p className="ghost-prose">
                      {p2}
                      {!complete && <span className="ghost-caret"/>}
                    </p>
                  )}
                  <StreamActions complete={complete}/>
                </div>
              </div>
            </div>
          </div>

          <div className="statusbar">
            <span className={complete ? "live" : "streaming"}>
              {complete ? "draft ready · Tab to accept" : "agent streaming"}
            </span>
            <span className="sep">·</span>
            <span>{complete ? "487 tokens · 2.1s" : "streaming inline at caret"}</span>
            <span style={{ flex: 1 }}/>
            <span>~/flyt/agent-streaming-protocol</span>
          </div>
        </main>
      </div>
    </div>
  );
};

window.StreamingScreen = StreamingScreen;
window.Presence = Presence;
window.useTypewriter = useTypewriter;
