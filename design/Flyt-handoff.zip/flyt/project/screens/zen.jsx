// flyt — Zen mode
// Just writing. Sidebar gone, header gone, chrome reduced to a whisper.
// A small ambient save dot fades in/out. Esc-to-exit hint dissolves after a beat.

const zenContent = [
  { type: "h1", text: "On writing as a single, slow surface" },
  { type: "p", text: "The most useful tool I own is a page that does nothing. It does not autocomplete. It does not summarize. It does not propose. It waits for me to put a sentence down, and then it waits again." },
  { type: "p", text: "When I gave myself this — just a page, the right typeface, a column the width of forearm — I started to finish things again." },
  { type: "h2", text: "What changes" },
  { type: "p", text: "Removing the sidebar is not a cosmetic move. The sidebar was a list of other places I could go instead of finishing this sentence. With it offscreen, the only available action is the next word." },
  { type: "p", text: "Removing the top bar removes status. Status, I have noticed, is mostly a tax. The model still saves. The path still exists. I just no longer have to think about either while I am still mid-thought." },
  { type: "h2", text: "What stays" },
  { type: "p", text: "The cursor. A breath of metadata in the corner, almost too quiet to read. A faint hint that Esc will bring the rest back when I'm ready for it. That's the whole interface.", caret: true },
];

const ZenScreen = () => {
  const [hintVisible, setHintVisible] = React.useState(true);
  const [saveState, setSaveState] = React.useState("saved");

  React.useEffect(() => {
    const t = setTimeout(() => setHintVisible(false), 3200);
    return () => clearTimeout(t);
  }, []);

  // pulse save state every so often to suggest live persistence
  React.useEffect(() => {
    let live = true;
    const tick = () => {
      if (!live) return;
      setSaveState("saving");
      setTimeout(() => { if (live) setSaveState("saved"); }, 700);
    };
    const iv = setInterval(tick, 7000);
    return () => { live = false; clearInterval(iv); };
  }, []);

  return (
    <div className="flyt zen">
      {/* whisper-quiet window chrome — only the dots, no title, no border */}
      <div className="zen-chrome">
        <div className="win-dots">
          <span className="win-dot r"></span>
          <span className="win-dot y"></span>
          <span className="win-dot g"></span>
        </div>
      </div>

      <main className="zen-stage">
        <div className="editor-col zen-col">
          <Doc blocks={zenContent}/>
        </div>
      </main>

      {/* ambient save dot — top-right corner */}
      <div className="zen-ambient">
        <span className={"zen-dot " + saveState}/>
        <span className="zen-ambient-label">{saveState}</span>
      </div>

      {/* esc hint — fades out after a beat */}
      <div className={"zen-hint" + (hintVisible ? " visible" : "")}>
        <Kbd>Esc</Kbd>
        <span>exit zen</span>
      </div>
    </div>
  );
};

window.ZenScreen = ZenScreen;
