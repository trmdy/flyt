// flyt — Command palette / quick open
// ⌘K opens a unified palette: commands, recent docs, agent actions, search-in-docs.

const PaletteItem = ({ icon, label, sub, meta, active, type }) => (
  <div className={"palette-item" + (active ? " active" : "")}>
    <span className="ico" style={{ width: 16, justifyContent: "center", display: "flex" }}>
      <Icon name={icon} size={14}/>
    </span>
    <span>{label}</span>
    {sub && <span className="sub">{sub}</span>}
    <span className="meta">{meta}</span>
  </div>
);

const PaletteScreen = () => {
  return (
    <div className="flyt" style={{ position: "relative" }}>
      <WinChrome title="~/flyt"/>
      <div style={{ display: "flex", flex: "1 1 auto", minHeight: 0 }}>
        <RecentsSidebar active={0}/>

        <main className="main">
          <div className="topbar">
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ fontFamily: "var(--mono)", fontSize: 11.5, color: "var(--ink-3)" }}>Product</span>
              <Icon name="chevron-right" size={11} style={{ color: "var(--ink-4)" }}/>
              <span style={{ fontFamily: "var(--mono)", fontSize: 11.5, color: "var(--ink-2)" }}>agent-streaming-protocol</span>
            </div>
            <div style={{ flex: 1 }}/>
          </div>

          <div className="editor-stage">
            <div className="editor-col">
              <Doc blocks={sampleContent.slice(0, 5)}/>
            </div>
          </div>

          <div className="statusbar">
            <span className="live">saved · 2s ago</span>
            <span className="sep">·</span>
            <span>2,840 words</span>
            <span style={{ flex: 1 }}/>
          </div>
        </main>
      </div>

      {/* palette overlay */}
      <div className="scrim">
        <div className="palette">
          <div className="palette-input">
            <Icon name="search" size={15} style={{ color: "var(--ink-3)" }}/>
            <input placeholder="Type a command, search docs, or ask…" defaultValue="strea"/>
            <span style={{ display: "flex", alignItems: "center", gap: 6, fontFamily: "var(--mono)", fontSize: 10.5, color: "var(--ink-4)" }}>
              <span style={{ padding: "2px 6px", borderRadius: 3, background: "var(--canvas-2)", color: "var(--ink-3)" }}>all</span>
              <Kbd>⌘K</Kbd>
            </span>
          </div>

          <div className="palette-list">
            <div className="palette-section-label">Entries</div>
            <PaletteItem
              icon="file-md"
              label="Agent streaming protocol"
              sub="open"
              meta="↵"
              active
            />
            <PaletteItem
              icon="file-md"
              label="Slate block model — extending for streamable nodes"
              meta="May 19"
            />
            <PaletteItem
              icon="file-md"
              label="Solo founder writing patterns — week 23"
              meta="May 21"
            />

            <div className="palette-section-label">Agent</div>
            <PaletteItem
              icon="sparkles"
              label="Generate side draft from selection"
              meta="⌘⇧J"
            />
            <PaletteItem
              icon="sparkles"
              label="Continue writing at caret"
              meta="⌘J"
            />
            <PaletteItem
              icon="wand"
              label="Outline this entry"
            />
            <PaletteItem
              icon="branch"
              label="Diff against previous draft"
            />

            <div className="palette-section-label">Commands</div>
            <PaletteItem
              icon="plus"
              label="New entry"
              meta="⌘N"
            />
            <PaletteItem
              icon="zen"
              label="Enter zen mode"
              meta="⇧⌘."
            />
            <PaletteItem
              icon="paperclip"
              label="Insert asset…"
              meta="⌘⇧I"
            />
            <PaletteItem
              icon="tag"
              label="Set group…"
            />
            <PaletteItem
              icon="globe"
              label="Reveal in Finder"
            />
          </div>

          <div className="palette-foot">
            <span className="hint"><Kbd>↑↓</Kbd> navigate</span>
            <span className="hint"><Kbd>↵</Kbd> select</span>
            <span className="hint"><Kbd>⌘P</Kbd> entries only</span>
            <span className="hint"><Kbd>?</Kbd> ask agent</span>
            <span style={{ marginLeft: "auto", color: "var(--ink-3)" }}>filtering on "strea" · 7 results</span>
          </div>
        </div>
      </div>
    </div>
  );
};

window.PaletteScreen = PaletteScreen;
