// flyt — Asset insertion
// Editor with drawer for inserting image/gif/video. Assets live in _assets/.

const AssetDrawer = ({ tab, setTab, hot }) => {
  return (
    <div className="asset-drawer">
      <div className="asset-tabs">
        {["Upload", "From entry", "From URL", "Paste"].map(t => (
          <div
            key={t}
            className={"asset-tab" + (tab === t ? " active" : "")}
            onClick={() => setTab(t)}
          >
            {t}
          </div>
        ))}
      </div>

      {tab === "Upload" && (
        <>
          <div className={"asset-drop" + (hot ? " hot" : "")}>
            <span className="big">Drop an image, GIF, or short video</span>
            <span>or <span style={{ color: "var(--ink-2)", textDecoration: "underline", textUnderlineOffset: 3, textDecorationColor: "var(--ink-4)" }}>choose from disk</span>. Files are copied into <span style={{ fontFamily: "var(--mono)", color: "var(--ink-2)" }}>_assets/</span> beside this entry.</span>
          </div>
          <div className="asset-recent">
            <div className="asset-recent-label">In this entry · _assets/</div>
            <div className="asset-grid">
              <div className="asset-thumb" style={{ background: "linear-gradient(135deg, #d9c9a8 0%, #b89a6e 100%)" }}>
                <div className="type-badge">PNG</div>
                <div className="lbl">protocol-diagram.png</div>
              </div>
              <div className="asset-thumb" style={{ background: "linear-gradient(135deg, #c8b7a0 0%, #8a7558 100%)" }}>
                <div className="type-badge">GIF</div>
                <div className="lbl">streaming-flow.gif</div>
              </div>
              <div className="asset-thumb" style={{ background: "linear-gradient(135deg, #e8dcc4 0%, #c4a886 100%)" }}>
                <div className="type-badge">PNG</div>
                <div className="lbl">caret-states.png</div>
              </div>
              <div className="asset-thumb" style={{ background: "linear-gradient(135deg, #b8a589 0%, #7a6444 100%)" }}>
                <div className="type-badge">MP4</div>
                <div className="lbl">side-draft.mp4</div>
              </div>
            </div>
          </div>
        </>
      )}

      <div style={{
        borderTop: "1px solid var(--hair)",
        padding: "8px 14px",
        display: "flex",
        alignItems: "center",
        gap: 14,
        fontFamily: "var(--mono)",
        fontSize: 10.5,
        color: "var(--ink-4)",
        background: "var(--surface-warm)"
      }}>
        <span><Kbd>↑↓</Kbd> navigate</span>
        <span><Kbd>↵</Kbd> insert</span>
        <span><Kbd>esc</Kbd> close</span>
        <span style={{ marginLeft: "auto", color: "var(--ink-3)" }}>copies to ./_assets/</span>
      </div>
    </div>
  );
};

const AssetScreen = () => {
  const [tab, setTab] = React.useState("Upload");

  // editor content with a pending-embed placeholder
  return (
    <div className="flyt" style={{ position: "relative" }}>
      <WinChrome title="agent-streaming-protocol/index.md"/>
      <div style={{ display: "flex", flex: "1 1 auto", minHeight: 0 }}>
        <RecentsSidebar active={0}/>

        <main className="main">
          <div className="topbar">
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ fontFamily: "var(--mono)", fontSize: 11.5, color: "var(--ink-3)" }}>Product</span>
              <Icon name="chevron-right" size={11} style={{ color: "var(--ink-4)" }}/>
              <span style={{ fontFamily: "var(--mono)", fontSize: 11.5, color: "var(--ink-2)" }}>agent-streaming-protocol</span>
            </div>
            <div style={{ flex: 1 }}/>
          </div>

          <div className="editor-stage">
            <div className="editor-col">
              <h1 style={{
                fontFamily: "var(--prose)",
                fontSize: 38,
                lineHeight: 1.15,
                margin: "0 0 6px",
                fontWeight: 500,
                letterSpacing: "-0.015em"
              }}>Agent streaming protocol</h1>
              <div className="doc-meta">
                <span>Spec</span><span className="dot"/><span>edited just now</span>
              </div>
              <div className="doc">
                <p>The editor is the source of truth. Agents propose; humans dispose. Anywhere we make this asymmetric — by autoplaying replacements, by writing without a draft, by streaming over the user's caret — we get it wrong.</p>

                <h2>Surface area</h2>
                <p>Two entry points only: an inline ⌘J continuation at the caret, and a side-draft generation triggered from the command palette.</p>

                {/* pending embed */}
                <div className="embed-pending">
                  <div className="thumb" style={{ background: "linear-gradient(135deg, #d9c9a8 0%, #b89a6e 100%)" }}/>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div className="name">protocol-diagram.png</div>
                    <div className="path">_assets/protocol-diagram.png · 248 KB</div>
                    <div className="progress"><div className="bar"/></div>
                  </div>
                </div>

                <p style={{ color: "var(--ink-4)" }}>
                  <span className="md-token">![diagram](_assets/protocol-diagram.png)</span>
                </p>
              </div>
            </div>
          </div>

          <div className="statusbar">
            <span className="live">saved · 2s ago</span>
            <span className="sep">·</span>
            <span>copying protocol-diagram.png → _assets/</span>
            <span style={{ flex: 1 }}/>
            <span>md</span>
          </div>
        </main>
      </div>

      {/* overlay */}
      <div className="scrim" style={{ paddingTop: 120 }}>
        <AssetDrawer tab={tab} setTab={setTab} hot={true}/>
      </div>
    </div>
  );
};

window.AssetScreen = AssetScreen;
