// flyt — Cmd-J with no selection
// A sleek inline prompt appears at the caret. The writer types what they want
// the agent to write here, and on ↵ the response streams in place.

const promptSuggestions = [
  { label: "Outline this section", hint: "structure" },
  { label: "Continue from here", hint: "extend" },
  { label: "Summarize above", hint: "compress" },
  { label: "Write the tradeoffs", hint: "expand" },
];

const InlinePrompt = ({ value = "", focused = true }) => (
  <div className="inline-prompt">
    <div className="ip-row">
      <Icon name="sparkles" size={14} style={{ color: "var(--ochre)", flex: "0 0 auto" }}/>
      <div className="ip-input-wrap">
        <input
          className="ip-input"
          placeholder="Tell the agent what to write here…"
          defaultValue={value}
          readOnly
        />
        {focused && !value && <span className="ip-caret"/>}
      </div>
      <span className="ip-anchor">
        <Icon name="hash" size={11} style={{ color: "var(--ink-4)" }}/>
        <span>at line 7</span>
      </span>
      <button className="ip-submit" aria-label="Submit">
        <Icon name="arrow-right" size={12} stroke={1.8}/>
      </button>
    </div>
    <div className="ip-suggestions">
      <span className="ip-suggestions-label">Or try</span>
      {promptSuggestions.map((s, i) => (
        <button key={i} className={"ip-chip" + (i === 0 ? " primary" : "")}>
          <span>{s.label}</span>
          <span className="ip-chip-hint">{s.hint}</span>
        </button>
      ))}
      <span className="ip-hint">
        <Kbd>↵</Kbd>
        <span style={{ marginLeft: 6, color: "var(--ink-4)" }}>submit</span>
        <span style={{ margin: "0 8px", color: "var(--ink-5)" }}>·</span>
        <Kbd>Esc</Kbd>
        <span style={{ marginLeft: 6, color: "var(--ink-4)" }}>dismiss</span>
      </span>
    </div>
  </div>
);

const PromptAtCaretScreen = () => {
  return (
    <div className="flyt">
      <WinChrome title="agent-streaming-protocol/index.md"/>
      <div style={{ display: "flex", flex: "1 1 auto", minHeight: 0 }}>
        <RecentsSidebar active={0}/>

        <main className="main">
          <div className="topbar">
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <button className="btn-quiet" style={{ padding: 4 }}>
                <Icon name="sidebar" size={14}/>
              </button>
              <span style={{ fontFamily: "var(--mono)", fontSize: 11.5, color: "var(--ink-3)" }}>Product</span>
              <Icon name="chevron-right" size={11} style={{ color: "var(--ink-4)" }}/>
              <span style={{ fontFamily: "var(--mono)", fontSize: 11.5, color: "var(--ink-2)" }}>agent-streaming-protocol</span>
            </div>
            <div style={{ flex: 1 }}/>
            <button className="btn-quiet"><Icon name="sparkles" size={13}/><span>Ask</span><Kbd>⌘J</Kbd></button>
          </div>

          <div className="editor-stage" style={{ padding: "56px 40px 140px" }}>
            <div className="editor-col">
              <h1 style={{
                fontFamily: "var(--prose)", fontSize: 38, lineHeight: 1.15,
                margin: "0 0 6px", fontWeight: 500, letterSpacing: "-0.015em"
              }}>Agent streaming protocol</h1>
              <div className="doc-meta">
                <span>Spec</span><span className="dot"/><span>edited just now</span>
              </div>

              <div className="doc">
                <p>Define the streaming contract between the editor host and a remote model. Tokens arrive over a server-sent event stream; the host owns reconciliation against the in-memory document, persistence to disk, and visible UI state.</p>

                <h2>Surface area</h2>
                <p>The editor is the source of truth. Agents propose; humans dispose. We hold this asymmetric: any time an agent would mutate the document without a draft, we route it through a draft instead.</p>

                <h2>Tradeoffs</h2>

                {/* prompt appears here, between empty h2 and next content */}
                <InlinePrompt/>
              </div>
            </div>
          </div>

          <div className="statusbar">
            <span className="live">saved · 2s ago</span>
            <span className="sep">·</span>
            <span>asking at caret · line 7</span>
            <span style={{ flex: 1 }}/>
            <span>⌘J · prompt the agent</span>
          </div>
        </main>
      </div>
    </div>
  );
};

window.PromptAtCaretScreen = PromptAtCaretScreen;
window.InlinePrompt = InlinePrompt;
