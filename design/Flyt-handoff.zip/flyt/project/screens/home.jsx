// flyt — Home / library view
// Lists all entries with search, filter chips, recents pinned.

const homeEntries = [
  {
    id: "agent-streaming-protocol",
    title: "Agent streaming protocol",
    preview: "Define the streaming contract between the editor host and a remote model. Tokens arrive over SSE; the host owns reconciliation…",
    tag: "spec", tagLabel: "Spec",
    date: "Today", time: "3:42 PM",
    words: 2840,
  },
  {
    id: "q3-product-bets",
    title: "Q3 product bets",
    preview: "Three things we're committing to: 1) durable thinking surface, 2) native agent runtime, 3) file-on-disk as the source of truth…",
    tag: "plan", tagLabel: "Plan",
    date: "Today", time: "11:08 AM",
    words: 1204,
  },
  {
    id: "interview-notes-aria",
    title: "Interview — Aria, founding designer",
    preview: "Background in editorial systems. Worked on the type stack at Readwise. Has strong opinions on prose width and trailing whitespace…",
    tag: "note", tagLabel: "Note",
    date: "Yesterday", time: "5:21 PM",
    words: 612,
  },
  {
    id: "flyt-positioning",
    title: "Positioning — flyt is not a chat app",
    preview: "We keep getting compared to Cursor and Notion AI. Neither is the right reference. flyt is a writing tool that happens to have…",
    tag: "brief", tagLabel: "Brief",
    date: "Yesterday", time: "2:14 PM",
    words: 1893,
  },
  {
    id: "slate-block-model",
    title: "Slate block model — extending for streamable nodes",
    preview: "Slate's editor model expects synchronous, deterministic operations. Streaming agent output violates both assumptions, so we…",
    tag: "spec", tagLabel: "Spec",
    date: "Mon", time: "—",
    words: 3477,
  },
  {
    id: "user-research-w23",
    title: "Solo founder writing patterns — week 23",
    preview: "Six interviews, four common patterns. The strongest signal: people keep writing markdown in chat threads to a model, then…",
    tag: "research", tagLabel: "Research",
    date: "May 21", time: "—",
    words: 2156,
  },
  {
    id: "onboarding-first-doc",
    title: "Onboarding — the first document",
    preview: "The first 30 seconds are everything. New users land on an empty editor that already contains a single sentence inviting them to…",
    tag: "brief", tagLabel: "Brief",
    date: "May 19", time: "—",
    words: 894,
  },
  {
    id: "filename-conventions",
    title: "Filename + folder conventions on disk",
    preview: "Each entry is a folder. The folder name is the slugified title at creation time and never changes. Inside: index.md and _assets/…",
    tag: "spec", tagLabel: "Spec",
    date: "May 17", time: "—",
    words: 720,
  },
];

const recentEntries = [
  { id: "agent-streaming-protocol", title: "Agent streaming protocol" },
  { id: "q3-product-bets", title: "Q3 product bets" },
  { id: "interview-notes-aria", title: "Interview — Aria, founding designer" },
];

const HomeScreen = () => {
  const [activeChip, setActiveChip] = React.useState("all");
  const chips = [
    { id: "all", label: "All", count: 47 },
    { id: "spec", label: "Spec", count: 12 },
    { id: "plan", label: "Plan", count: 6 },
    { id: "note", label: "Note", count: 18 },
    { id: "brief", label: "Brief", count: 7 },
    { id: "research", label: "Research", count: 4 },
  ];

  return (
    <div className="flyt">
      <WinChrome title="~/flyt"/>
      <div style={{ display: "flex", flex: "1 1 auto", minHeight: 0 }}>
        {/* sidebar */}
        <aside className="sb">
          <div className="brand">
            <div className="brand-name">flyt</div>
          </div>

          <div>
            <div className="sb-list">
              <div className="sb-item active">
                <span className="ico"><Icon name="doc-lines" size={14}/></span>
                <span>All entries</span>
                <span className="count">47</span>
              </div>
              <div className="sb-item">
                <span className="ico"><Icon name="clock" size={14}/></span>
                <span>Recent</span>
              </div>
              <div className="sb-item">
                <span className="ico"><Icon name="star" size={14}/></span>
                <span>Starred</span>
                <span className="count">5</span>
              </div>
              <div className="sb-item">
                <span className="ico"><Icon name="archive" size={14}/></span>
                <span>Archive</span>
              </div>
            </div>
          </div>

          <div>
            <div className="sb-section-label">Groups</div>
            <div className="sb-list">
              <div className="sb-item">
                <span className="ico"><Icon name="hash" size={14}/></span>
                <span>Product</span>
                <span className="count">14</span>
              </div>
              <div className="sb-item">
                <span className="ico"><Icon name="hash" size={14}/></span>
                <span>Engineering</span>
                <span className="count">11</span>
              </div>
              <div className="sb-item">
                <span className="ico"><Icon name="hash" size={14}/></span>
                <span>Research</span>
                <span className="count">4</span>
              </div>
              <div className="sb-item">
                <span className="ico"><Icon name="hash" size={14}/></span>
                <span>Journal</span>
                <span className="count">18</span>
              </div>
            </div>
          </div>

          <div style={{ marginTop: "auto", paddingTop: 12, borderTop: "1px solid var(--hair)" }}>
            <div className="sb-item" style={{ fontSize: 12.5 }}>
              <span className="ico"><Icon name="settings" size={13}/></span>
              <span>Settings</span>
            </div>
          </div>
        </aside>

        {/* main */}
        <main className="main">
          <div className="topbar">
            <div className="search">
              <Icon name="search" size={14}/>
              <input placeholder="Search entries, contents, agents…"/>
              <Kbd>⌘K</Kbd>
            </div>
            <div style={{ flex: 1 }}/>
            <button className="btn-quiet">
              <Icon name="filter" size={13}/>
              <span>Filter</span>
            </button>
            <button className="btn-ink">
              <Icon name="plus" size={13}/>
              <span>New entry</span>
              <Kbd style={{ marginLeft: 4 }}>⌘N</Kbd>
            </button>
          </div>

          <div style={{ flex: "1 1 auto", overflow: "auto" }}>
            <div className="entries">
              <div className="entries-head">
                <div>
                  <div className="entries-title">All entries</div>
                </div>
                <div className="entries-sub">47 documents · sorted by edited</div>
              </div>

              <div className="chips">
                {chips.map(c => (
                  <button
                    key={c.id}
                    className={"chip" + (activeChip === c.id ? " active" : "")}
                    onClick={() => setActiveChip(c.id)}
                  >
                    <span>{c.label}</span>
                    <span className="count">{c.count}</span>
                  </button>
                ))}
              </div>

              {homeEntries.map(e => (
                <div className="entry-row" key={e.id}>
                  <div style={{ minWidth: 0 }}>
                    <div className="entry-title">{e.title}</div>
                    <div className="entry-preview">{e.preview}</div>
                  </div>
                  <div className={"entry-tag " + e.tag}>{e.tagLabel}</div>
                  <div className="entry-date">
                    {e.date}
                    {e.time !== "—" && <div style={{ opacity: 0.65, marginTop: 2 }}>{e.time}</div>}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="statusbar">
            <span>47 entries</span>
            <span className="sep">·</span>
            <span>~/Documents/flyt</span>
            <span style={{ flex: 1 }}/>
            <span className="live">in sync</span>
          </div>
        </main>
      </div>
    </div>
  );
};

window.HomeScreen = HomeScreen;
