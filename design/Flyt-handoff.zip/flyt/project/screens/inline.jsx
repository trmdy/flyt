// flyt — Inline continuation
// Close-up of the editor with ghost-text streaming after the caret.

const inlineBlocks = [
  { type: "h2", text: "Inline continuation" },
];

const inlineGhost = "It feels less like generating and more like the model finishing the sentence you were already typing.";

const InlineContinueScreen = () => {
  const [ghost, complete] = useTypewriter(inlineGhost, 3, 38);
  return (
    <div className="flyt">
      <WinChrome title="agent-streaming-protocol/index.md"/>
      <div style={{ display: "flex", flex: "1 1 auto", minHeight: 0 }}>
        <main className="main">
          <div className="topbar">
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ fontFamily: "var(--mono)", fontSize: 11.5, color: "var(--ink-3)" }}>Product</span>
              <Icon name="chevron-right" size={11} style={{ color: "var(--ink-4)" }}/>
              <span style={{ fontFamily: "var(--mono)", fontSize: 11.5, color: "var(--ink-2)" }}>agent-streaming-protocol</span>
            </div>
            <div style={{ flex: 1 }}/>
            <button className="btn-quiet"><Icon name="sparkles" size={13}/><span>Ask</span><Kbd>⌘J</Kbd></button>
          </div>

          <div className="editor-stage" style={{ padding: "72px 40px 100px" }}>
            <div className="editor-col">
              <div className="doc">
                <h2>Inline continuation</h2>
                <p>
                  For short completions — finishing a sentence, expanding a bullet — the model streams ghost text directly after the caret.{" "}
                  <span className="ghost-continue">
                    {ghost}
                    {!complete && <span className="ghost-cursor"/>}
                  </span>
                </p>

                {/* hint chip floating */}
                <div style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 8,
                  marginTop: 24,
                  padding: "8px 12px",
                  border: "1px solid var(--hair)",
                  borderRadius: 6,
                  background: "var(--surface-warm)",
                  fontFamily: "var(--ui)",
                  fontSize: 12,
                  color: "var(--ink-2)",
                  width: "fit-content"
                }}>
                  <Icon name="sparkles" size={12} style={{ color: "var(--ochre)" }}/>
                  <span style={{ marginRight: 6 }}>Continuing</span>
                  <span style={{ color: "var(--ink-4)" }}>·</span>
                  <span style={{ marginLeft: 6 }}>
                    <Kbd>Tab</Kbd>
                    <span style={{ margin: "0 6px", color: "var(--ink-4)" }}>accept</span>
                  </span>
                  <span>
                    <Kbd>⌘ →</Kbd>
                    <span style={{ margin: "0 6px", color: "var(--ink-4)" }}>word</span>
                  </span>
                  <span>
                    <Kbd>Esc</Kbd>
                    <span style={{ marginLeft: 6, color: "var(--ink-4)" }}>dismiss</span>
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className="statusbar">
            <span className="streaming">continuing inline</span>
            <span className="sep">·</span>
            <span>{complete ? "ready · Tab to accept" : "streaming"}</span>
            <span style={{ flex: 1 }}/>
            <span>haiku-4-5</span>
          </div>
        </main>
      </div>
    </div>
  );
};

window.InlineContinueScreen = InlineContinueScreen;
