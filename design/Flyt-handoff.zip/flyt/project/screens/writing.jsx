// flyt — Writing view (interactive editor)
// Centered Slate-like editor, collapsible recent-docs sidebar, quiet status.

const sampleContent = [
  { type: "h1", text: "Agent streaming protocol" },
  { type: "meta", text: "Spec · v0.3 · last edited just now" },
  { type: "p", text: "Define the streaming contract between the editor host and a remote model. Tokens arrive over a server-sent event stream; the host owns reconciliation against the in-memory document, persistence to disk, and visible UI state." },
  { type: "p", text: "The editor is the source of truth. Agents propose; humans dispose. Anywhere we make this asymmetric — by autoplaying replacements, by writing without a draft, by streaming over the user's caret — we get it wrong." },
  { type: "h2", text: "Goals", showTokens: true, token: "##" },
  { type: "ul", items: [
    "Streaming feels live, never spinning.",
    "Large generations land as a side draft the writer accepts or discards.",
    "Small in-place continuations are reversible with a single keystroke.",
    "Disk persistence never blocks input.",
  ]},
  { type: "h2", text: "Non-goals" },
  { type: "ul", items: [
    "Multi-agent orchestration. One model, one stream.",
    "Conflict resolution across collaborators. Single writer for v1.",
  ]},
  { type: "h2", text: "Surface area" },
  { type: "p", text: "Two entry points only: an inline ⌘J continuation at the caret, and a side-draft generation triggered from the command palette. Both produce a reversible operation against the current document.", caret: true },
];

const RecentsSidebar = ({ active }) => (
  <aside className="sb">
    <div className="brand">
      <div className="brand-name">flyt</div>
    </div>

    <div>
      <div className="sb-list">
        <div className="sb-item">
          <span className="ico"><Icon name="doc-lines" size={14}/></span>
          <span>All entries</span>
        </div>
        <div className="sb-item">
          <span className="ico"><Icon name="plus" size={14}/></span>
          <span>New entry</span>
          <span className="count" style={{ fontFamily: "var(--mono)" }}>⌘N</span>
        </div>
      </div>
    </div>

    <div>
      <div className="sb-section-label">Recent</div>
      <div className="sb-list">
        <div className={"sb-item" + (active === 0 ? " active" : "")}>
          <span className="ico"><Icon name="file-md" size={14}/></span>
          <span>Agent streaming protocol</span>
        </div>
        <div className="sb-item">
          <span className="ico"><Icon name="file-md" size={14}/></span>
          <span>Q3 product bets</span>
        </div>
        <div className="sb-item">
          <span className="ico"><Icon name="file-md" size={14}/></span>
          <span>Interview — Aria, founding…</span>
        </div>
        <div className="sb-item">
          <span className="ico"><Icon name="file-md" size={14}/></span>
          <span>Positioning — flyt is not…</span>
        </div>
        <div className="sb-item">
          <span className="ico"><Icon name="file-md" size={14}/></span>
          <span>Slate block model</span>
        </div>
        <div className="sb-item">
          <span className="ico"><Icon name="file-md" size={14}/></span>
          <span>Solo founder writing pa…</span>
        </div>
      </div>
    </div>

    <div>
      <div className="sb-section-label">In this entry</div>
      <div className="sb-list" style={{ fontFamily: "var(--prose)", fontSize: 12.5 }}>
        <div className="sb-item" style={{ paddingLeft: 8 }}>Goals</div>
        <div className="sb-item" style={{ paddingLeft: 8 }}>Non-goals</div>
        <div className="sb-item" style={{ paddingLeft: 8 }}>Surface area</div>
        <div className="sb-item" style={{ paddingLeft: 18, color: "var(--ink-3)", fontSize: 12 }}>Inline continuations</div>
        <div className="sb-item" style={{ paddingLeft: 18, color: "var(--ink-3)", fontSize: 12 }}>Side drafts</div>
      </div>
    </div>
  </aside>
);

const Doc = ({ blocks, editable }) => {
  return (
    <div className="doc" contentEditable={editable} suppressContentEditableWarning>
      {blocks.map((b, i) => {
        if (b.type === "h1") return <h1 key={i}>{b.text}</h1>;
        if (b.type === "meta") return <div key={i} className="doc-meta">
          <span>Spec</span><span className="dot"/><span>edited just now</span>
        </div>;
        if (b.type === "h2") return (
          <h2 key={i}>
            {b.showTokens && <span className="md-token">## </span>}
            {b.text}
          </h2>
        );
        if (b.type === "p") return (
          <p key={i}>
            {b.text}
            {b.caret && <span className="caret"/>}
          </p>
        );
        if (b.type === "ul") return (
          <ul key={i}>
            {b.items.map((it, j) => <li key={j}>{it}</li>)}
          </ul>
        );
        return null;
      })}
    </div>
  );
};

const WritingScreen = ({ editable = false, statusOverride, showAgentStream = false }) => {
  return (
    <div className="flyt">
      <WinChrome title="agent-streaming-protocol/index.md"/>
      <div style={{ display: "flex", flex: "1 1 auto", minHeight: 0 }}>
        <RecentsSidebar active={0}/>

        <main className="main">
          <div className="topbar">
            <div style={{ display: "flex", alignItems: "center", gap: 8, color: "var(--ink-3)" }}>
              <button className="btn-quiet" style={{ padding: 4 }}>
                <Icon name="sidebar" size={14}/>
              </button>
              <span style={{ fontFamily: "var(--mono)", fontSize: 11.5, color: "var(--ink-3)" }}>
                Product
              </span>
              <Icon name="chevron-right" size={11} style={{ color: "var(--ink-4)" }}/>
              <span style={{ fontFamily: "var(--mono)", fontSize: 11.5, color: "var(--ink-2)" }}>
                agent-streaming-protocol
              </span>
            </div>
            <div style={{ flex: 1 }}/>
            <button className="btn-quiet"><Icon name="sparkles" size={13}/><span>Ask</span><Kbd>⌘J</Kbd></button>
          </div>

          <div className="editor-stage">
            <div className="editor-col">
              <Doc blocks={sampleContent} editable={editable}/>
            </div>
          </div>

          <div className="statusbar">
            {statusOverride || (
              <>
                <span className="live">saved · 2s ago</span>
                <span className="sep">·</span>
                <span>2,840 words</span>
                <span className="sep">·</span>
                <span>~/flyt/agent-streaming-protocol/index.md</span>
                <span style={{ flex: 1 }}/>
                <span>md</span>
                <span className="sep">·</span>
                <span>UTF-8</span>
                <span className="sep">·</span>
                <span>Ln 24 · Col 41</span>
              </>
            )}
          </div>
        </main>
      </div>
    </div>
  );
};

window.WritingScreen = WritingScreen;
window.RecentsSidebar = RecentsSidebar;
window.Doc = Doc;
window.sampleContent = sampleContent;
