// flyt — Inline selection toolbar
// Sleek floating toolbar above a text selection. Hairlines, small icons,
// mono shortcut tooltip on hover. Includes an "Ask" mode that morphs the
// toolbar into a single-line prompt scoped to the selected range.

const STBtn = ({ icon, label, shortcut, active, onClick, ariaLabel, children, style }) => (
  <button
    className={"st-btn" + (active ? " active" : "")}
    onClick={onClick}
    aria-label={ariaLabel || label}
    style={style}
    title={shortcut ? `${label} · ${shortcut}` : label}
  >
    {icon ? <Icon name={icon} size={13} stroke={1.6}/> : children}
  </button>
);

const STDivider = () => <span className="st-divider"/>;

const ToolbarResting = ({ style }) => (
  <div className="selection-toolbar" style={style}>
    <STBtn ariaLabel="Bold" label="Bold" shortcut="⌘B">
      <span className="st-glyph" style={{ fontWeight: 700 }}>B</span>
    </STBtn>
    <STBtn ariaLabel="Italic" label="Italic" shortcut="⌘I">
      <span className="st-glyph" style={{ fontStyle: "italic", fontFamily: "var(--prose)" }}>I</span>
    </STBtn>
    <STBtn ariaLabel="Code" label="Code" shortcut="⌘E">
      <span className="st-glyph" style={{ fontFamily: "var(--mono)", fontSize: 12 }}>{"</>"}</span>
    </STBtn>
    <STBtn icon="link" ariaLabel="Link" label="Link" shortcut="⌘K"/>
    <STDivider/>
    <STBtn ariaLabel="Heading" label="Heading" shortcut="⌘⌥2">
      <span className="st-glyph" style={{ fontFamily: "var(--prose)", fontWeight: 600, fontSize: 13 }}>H<sub style={{ fontSize: 9, fontFamily: "var(--mono)", fontWeight: 400 }}>2</sub></span>
    </STBtn>
    <STBtn ariaLabel="Quote" label="Quote" shortcut="⌘⇧.">
      <span className="st-glyph" style={{ fontFamily: "var(--prose)", fontSize: 18, lineHeight: 1, position: "relative", top: -1 }}>"</span>
    </STBtn>
    <STDivider/>
    <button className="st-ask" title="Ask about selection — ⌘J">
      <Icon name="sparkles" size={12} style={{ color: "var(--ochre)" }}/>
      <span>Ask</span>
      <span className="st-kbd">⌘J</span>
    </button>
    <div className="st-arrow"/>
  </div>
);

const ToolbarAsk = ({ style }) => (
  <div className="selection-toolbar st-ask-mode" style={style}>
    <Icon name="sparkles" size={13} style={{ color: "var(--ochre)", flex: "0 0 auto" }}/>
    <input
      className="st-input"
      placeholder="tighten this · explain · rewrite as…"
      defaultValue="rewrite as a single sentence"
    />
    <button className="st-submit" aria-label="Submit">
      <Icon name="arrow-right" size={12} stroke={1.8}/>
    </button>
    <div className="st-arrow"/>
  </div>
);

// Editor with a real selection highlighted under the toolbar position.
const EditorWithSelection = ({ mode = "resting" }) => {
  return (
    <div className="editor-stage" style={{ padding: "56px 40px 120px", position: "relative" }}>
      <div className="editor-col">
        <h1 style={{
          fontFamily: "var(--prose)", fontSize: 38, lineHeight: 1.15,
          margin: "0 0 6px", fontWeight: 500, letterSpacing: "-0.015em"
        }}>Agent streaming protocol</h1>
        <div className="doc-meta">
          <span>Spec</span><span className="dot"/><span>edited just now</span>
        </div>

        <div className="doc">
          <p>Define the streaming contract between the editor host and a remote model. Tokens arrive over a server-sent event stream; the host owns reconciliation against the in-memory document, persistence to disk, and visible UI state.</p>

          <div style={{ position: "relative", marginBottom: 64 }}>
            <p>
              The editor is the source of truth. Agents propose; humans dispose. Anywhere we make this asymmetric — by autoplaying replacements, by writing without a draft, by{" "}
              <span className="selection-range">streaming over the user's caret — we get it wrong</span>.
            </p>
            {mode === "resting" && (
              <ToolbarResting style={{ position: "absolute", top: "100%", marginTop: 10, left: "32%" }}/>
            )}
            {mode === "ask" && (
              <ToolbarAsk style={{ position: "absolute", top: "100%", marginTop: 10, left: "8%", width: 580 }}/>
            )}
          </div>

          <h2>Goals</h2>
          <ul>
            <li>Streaming feels live, never spinning.</li>
            <li>Large generations land as a side draft.</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

const SelectionScreen = ({ mode = "resting" }) => {
  return (
    <div className="flyt">
      <WinChrome title="agent-streaming-protocol/index.md"/>
      <div style={{ display: "flex", flex: "1 1 auto", minHeight: 0 }}>
        <RecentsSidebar active={0}/>
        <main className="main">
          <div className="topbar">
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <button className="btn-quiet" style={{ padding: 4 }}>
                <Icon name="sidebar" size={14}/>
              </button>
              <span style={{ fontFamily: "var(--mono)", fontSize: 11.5, color: "var(--ink-3)" }}>Product</span>
              <Icon name="chevron-right" size={11} style={{ color: "var(--ink-4)" }}/>
              <span style={{ fontFamily: "var(--mono)", fontSize: 11.5, color: "var(--ink-2)" }}>agent-streaming-protocol</span>
            </div>
            <div style={{ flex: 1 }}/>
            <button className="btn-quiet"><Icon name="sparkles" size={13}/><span>Ask</span><Kbd>⌘J</Kbd></button>
          </div>

          <EditorWithSelection mode={mode}/>

          <div className="statusbar">
            <span className="live">saved · 2s ago</span>
            <span className="sep">·</span>
            {mode === "ask" ? (
              <span>asking on selection · 9 words</span>
            ) : (
              <span>selection · 9 words · 53 chars</span>
            )}
            <span style={{ flex: 1 }}/>
            <span>Ln 9 · Col 41</span>
          </div>
        </main>
      </div>
    </div>
  );
};

const SelectionRestingScreen = () => <SelectionScreen mode="resting"/>;
const SelectionAskScreen = () => <SelectionScreen mode="ask"/>;

window.SelectionRestingScreen = SelectionRestingScreen;
window.SelectionAskScreen = SelectionAskScreen;
window.ToolbarResting = ToolbarResting;
window.ToolbarAsk = ToolbarAsk;
