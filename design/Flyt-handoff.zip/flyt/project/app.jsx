// flyt — design canvas assembling all artboards

const PostIt = ({ children, w = 280 }) => (
  <DCPostIt width={w}>{children}</DCPostIt>
);

const App = () => {
  return (
    <DesignCanvas>
      <DCSection
        id="overview"
        title="01 · Concept"
        subtitle="The product in a paragraph, the system in a glance."
      >
        <DCArtboard id="brief" label="Brief" width={760} height={780} style={{ background: "#faf7f1" }}>
          <BriefCard/>
        </DCArtboard>
        <DCArtboard id="system" label="System" width={760} height={780} style={{ background: "#faf7f1" }}>
          <SystemCard/>
        </DCArtboard>
      </DCSection>

      <DCSection
        id="core"
        title="02 · App shell"
        subtitle="Home library and the writing surface."
      >
        <DCArtboard id="home" label="Home — library" width={1280} height={840} style={{ background: "#faf7f1" }}>
          <HomeScreen/>
        </DCArtboard>
        <DCArtboard id="writing" label="Writing — focused editor" width={1280} height={840} style={{ background: "#faf7f1" }}>
          <WritingScreen/>
        </DCArtboard>
        <DCArtboard id="zen" label="Zen mode — only writing" width={1280} height={840} style={{ background: "#faf7f1" }}>
          <ZenScreen/>
        </DCArtboard>
      </DCSection>

      <DCSection
        id="selection"
        title="03 · Inline toolbar"
        subtitle="Floats above a selection. Morphs into an ask prompt scoped to the range."
      >
        <DCArtboard id="selection-resting" label="Toolbar over selection" width={1280} height={840} style={{ background: "#faf7f1" }}>
          <SelectionRestingScreen/>
        </DCArtboard>
        <DCArtboard id="selection-ask" label="Ask mode — prompt on selection" width={1280} height={840} style={{ background: "#faf7f1" }}>
          <SelectionAskScreen/>
        </DCArtboard>
      </DCSection>

      <DCSection
        id="agent"
        title="04 · Agent — inline only"
        subtitle="No sidebar. The agent writes directly into the document, in place."
      >
        <DCArtboard id="prompt-at-caret" label="⌘J with no selection · prompt at caret" width={1280} height={840} style={{ background: "#faf7f1" }}>
          <PromptAtCaretScreen/>
        </DCArtboard>
        <DCArtboard id="streaming" label="Block stream · multi-paragraph generation in place" width={1280} height={840} style={{ background: "#faf7f1" }}>
          <StreamingScreen/>
        </DCArtboard>
        <DCArtboard id="inline" label="Inline continuation · finish-a-sentence ghost text" width={1280} height={840} style={{ background: "#faf7f1" }}>
          <InlineContinueScreen/>
        </DCArtboard>
      </DCSection>

      <DCSection
        id="inputs"
        title="05 · Inputs"
        subtitle="Asset insertion and the command palette."
      >
        <DCArtboard id="assets" label="Insert asset" width={1280} height={840} style={{ background: "#faf7f1" }}>
          <AssetScreen/>
        </DCArtboard>
        <DCArtboard id="palette" label="Command palette · ⌘K" width={1280} height={840} style={{ background: "#faf7f1" }}>
          <PaletteScreen/>
        </DCArtboard>
      </DCSection>
    </DesignCanvas>
  );
};

// ---- Concept cards (brief + system) ----

const BriefCard = () => (
  <div style={{
    height: "100%",
    padding: "44px 52px",
    background: "var(--canvas)",
    fontFamily: "var(--ui)",
    color: "var(--ink)",
    overflow: "hidden",
    display: "flex",
    flexDirection: "column",
    gap: 22
  }}>
    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
      <div className="brand-name" style={{ fontSize: 30 }}>flyt</div>
      <div style={{ marginLeft: 14, padding: "2px 8px", borderRadius: 999, border: "1px solid var(--hair-strong)", fontFamily: "var(--mono)", fontSize: 10.5, color: "var(--ink-3)", letterSpacing: 0 }}>v0.1 — design concept</div>
    </div>

    <div style={{
      fontFamily: "var(--prose)",
      fontSize: 32,
      lineHeight: 1.2,
      letterSpacing: "-0.015em",
      maxWidth: 560,
      color: "var(--ink)",
      textWrap: "pretty"
    }}>
      A clean desk for durable thinking, with agents that quietly help — not take over.
    </div>

    <div style={{
      fontFamily: "var(--prose)",
      fontSize: 16,
      lineHeight: 1.65,
      color: "var(--ink-2)",
      maxWidth: 540
    }}>
      flyt is a file-first markdown editor for a technical founder writing long-form specs, notes, and plans. Documents are folders on disk: <span style={{ fontFamily: "var(--mono)", fontSize: 14 }}>index.md</span> beside <span style={{ fontFamily: "var(--mono)", fontSize: 14 }}>_assets/</span>. Categories are metadata, not folders. Agents can read, patch, append, and stream into a document — but human writing is always primary.
    </div>

    <div style={{ display: "flex", gap: 28, marginTop: "auto" }}>
      <Pillar k="Typing" v="instant" note="UI never waits on disk or network. Persistence is fire-and-forget."/>
      <Pillar k="Agents" v="quiet" note="Side draft by default for big work; inline ghost text for small."/>
      <Pillar k="Surface" v="calm" note="iA Writer restraint, Linear speed, Notes warmth."/>
    </div>
  </div>
);

const Pillar = ({ k, v, note }) => (
  <div style={{ flex: 1, paddingTop: 18, borderTop: "1px solid var(--hair-strong)" }}>
    <div style={{ fontFamily: "var(--mono)", fontSize: 10.5, textTransform: "uppercase", letterSpacing: "0.08em", color: "var(--ink-4)" }}>{k}</div>
    <div style={{ fontFamily: "var(--prose)", fontSize: 22, marginTop: 4, fontWeight: 500, letterSpacing: "-0.01em" }}>{v}</div>
    <div style={{ fontFamily: "var(--prose)", fontSize: 14, color: "var(--ink-3)", marginTop: 6, lineHeight: 1.55 }}>{note}</div>
  </div>
);

const SystemCard = () => (
  <div style={{
    height: "100%",
    padding: "44px 52px",
    background: "var(--canvas)",
    fontFamily: "var(--ui)",
    color: "var(--ink)",
    overflow: "hidden",
    display: "flex",
    flexDirection: "column",
    gap: 22
  }}>
    <div style={{ display: "flex", alignItems: "baseline", gap: 12 }}>
      <div style={{ fontFamily: "var(--prose)", fontSize: 24, fontWeight: 500, letterSpacing: "-0.012em" }}>Visual system</div>
      <div style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--ink-4)" }}>type · color · density</div>
    </div>

    {/* Typography */}
    <div>
      <SectionLabel>Type</SectionLabel>
      <div style={{ display: "grid", gridTemplateColumns: "100px 1fr", gap: "14px 22px", marginTop: 10 }}>
        <div style={{ fontFamily: "var(--mono)", fontSize: 10.5, color: "var(--ink-4)", textTransform: "uppercase", letterSpacing: "0.08em", paddingTop: 8 }}>UI</div>
        <div>
          <div style={{ fontFamily: "var(--ui)", fontSize: 22, letterSpacing: "-0.01em" }}>Geist — refined sans, calm tracking</div>
          <div style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--ink-4)", marginTop: 4 }}>13–14px · -0.005em · weights 400 / 500</div>
        </div>

        <div style={{ fontFamily: "var(--mono)", fontSize: 10.5, color: "var(--ink-4)", textTransform: "uppercase", letterSpacing: "0.08em", paddingTop: 14 }}>Prose</div>
        <div>
          <div style={{ fontFamily: "var(--prose)", fontSize: 26, lineHeight: 1.3, letterSpacing: "-0.012em" }}>Newsreader — warm serif for reading</div>
          <div style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--ink-4)", marginTop: 4 }}>19px / 1.72 · optical sizing on · italic for emphasis</div>
        </div>

        <div style={{ fontFamily: "var(--mono)", fontSize: 10.5, color: "var(--ink-4)", textTransform: "uppercase", letterSpacing: "0.08em", paddingTop: 8 }}>Mono</div>
        <div>
          <div style={{ fontFamily: "var(--mono)", fontSize: 15 }}>Geist Mono — metadata · paths · shortcuts</div>
          <div style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--ink-4)", marginTop: 4 }}>10.5–12px · letter-spacing 0 · weights 400 / 500</div>
        </div>
      </div>
    </div>

    {/* Color */}
    <div>
      <SectionLabel>Palette · warm light only</SectionLabel>
      <div style={{ display: "flex", gap: 10, marginTop: 12 }}>
        <Swatch c="#faf7f1" name="canvas"/>
        <Swatch c="#f4f0e7" name="canvas-2"/>
        <Swatch c="#ffffff" name="surface"/>
        <Swatch c="#e8e1d2" name="hair"/>
        <Swatch c="#807769" name="ink-3"/>
        <Swatch c="#4a443c" name="ink-2"/>
        <Swatch c="#1c1915" name="ink"/>
        <Swatch c="#b8862f" name="ochre" note="streaming"/>
        <Swatch c="#6b7a3a" name="moss" note="saved"/>
        <Swatch c="#b65838" name="rust" note="stop"/>
      </div>
    </div>

    {/* Principles */}
    <div style={{ marginTop: "auto" }}>
      <SectionLabel>Principles</SectionLabel>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px 28px", marginTop: 10, fontFamily: "var(--prose)", fontSize: 14, lineHeight: 1.5, color: "var(--ink-2)" }}>
        <div><b style={{ color: "var(--ink)", fontWeight: 600 }}>Hairlines, not boxes.</b> One pixel of <span style={{ fontFamily: "var(--mono)", fontSize: 12 }}>--hair</span> separates concerns; cards and shadows are last resorts.</div>
        <div><b style={{ color: "var(--ink)", fontWeight: 600 }}>Mono for the machine.</b> Paths, counts, shortcuts and timestamps are mono; prose is serif; UI is sans.</div>
        <div><b style={{ color: "var(--ink)", fontWeight: 600 }}>One accent at a time.</b> Ochre means a thing is happening; moss means it's safe; rust means it's destructive.</div>
        <div><b style={{ color: "var(--ink)", fontWeight: 600 }}>Generous editor.</b> 720–820px column, 1.72 line-height, top padding 56px. The page breathes.</div>
      </div>
    </div>
  </div>
);

const SectionLabel = ({ children }) => (
  <div style={{ fontFamily: "var(--mono)", fontSize: 10.5, textTransform: "uppercase", letterSpacing: "0.08em", color: "var(--ink-4)", paddingBottom: 6, borderBottom: "1px solid var(--hair)" }}>{children}</div>
);

const Swatch = ({ c, name, note }) => (
  <div style={{ flex: 1 }}>
    <div style={{
      height: 56,
      borderRadius: 6,
      background: c,
      border: "1px solid var(--hair)",
      marginBottom: 8
    }}/>
    <div style={{ fontFamily: "var(--mono)", fontSize: 10.5, color: "var(--ink-2)" }}>{name}</div>
    {note && <div style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--ink-4)" }}>{note}</div>}
  </div>
);

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App/>);
